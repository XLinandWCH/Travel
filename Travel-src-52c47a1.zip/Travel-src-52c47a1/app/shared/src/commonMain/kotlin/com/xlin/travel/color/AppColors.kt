package com.xlin.travel.color

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * 全局颜色表（深色 / 浅色双主题）。
 *
 * 每个颜色都是 getter：组合函数中读取时会根据 [AppTheme.isDark] 返回对应主题的值，
 * 主题切换后所有用到的地方自动重组。名称沿用深色初稿的语义（如 TextWhite 在浅色
 * 主题下返回黑色），常量名保持不变，引用处无需改动。
 *
 * 注释中的来源标签对应 UI设计/ 目录下的初稿：
 * - [抽屉] 带导航抽屉的主聊天界面.html
 * - [输入框] 输入框设计初稿.html
 * - [设置] 设置界面UI初稿.html
 * - [消息] 聊天消息既有配色
 * 浅色主题没有独立初稿，按“白字变黑字、深底变浅底、白按钮变黑灰按钮”的规则取反。
 *
 * 全表不使用纯白 #FFFFFF 作表面色或正文色：纯白在手机屏上亮到刺眼。
 * 浅色主题的“白底”统一用冷中性柔白 [SoftWhiteSurface]（偏灰蓝、不带黄味），深色主题的
 * “白字 / 白图标”统一用近白中性白 [OffWhiteText]；只在半透明叠加（遮罩、hover 叠色）时
 * 才直接用白 / 黑 alpha。
 */

/** 浅色主题的卡片 / 弹层表面：冷中性柔白，代替纯白，避免高亮刺眼 */
private val SoftWhiteSurface = Color(0xFFFAFAFC)

/** 深色主题的文字 / 图标：接近纯白的中性白，代替纯白，长文阅读更舒适 */
private val OffWhiteText = Color(0xFFF2F3F5)

// ==================== 背景与容器 ====================
val ChatBackground: Color
    get() = themeColor(Color(0xFF1A1A1A), Color(0xD7EFEFF2))    // 全局页面背景（聊天 / 设置 / 搜索等子页面共用）
val SidebarBackground: Color
    get() = themeColor(Color(0xFF111111), Color(0xFFE8E9EC))    // 抽屉侧边栏背景 [抽屉]
val InputCardBackground: Color
    get() = themeColor(Color(0xFF2D2D2D), SoftWhiteSurface)      // 输入框卡片主体 [输入框]
val UserBubbleBackground: Color
    get() = themeColor(Color(0xFF2D2D2D), Color(0xFFE4E4E4))    // 用户消息气泡
val SettingCardBackground: Color
    get() = themeColor(Color(0xFF1E1E1E), SoftWhiteSurface)      // 设置分组卡片 --card [设置]
val IconButtonBackground: Color
    get() = themeColor(Color(0xFF1E1E1E), Color(0xFFE4E4E4))    // 圆形 / 方形图标按钮背景 [抽屉]
val SearchModalBackground: Color
    get() = themeColor(Color(0xFF1E1E1E), SoftWhiteSurface)      // 搜索弹窗面板 [抽屉]
val AvatarBackground: Color
    get() = themeColor(Color(0xFF333333), Color(0xFFD9D9D9))    // 用户头像圆底 [抽屉]
val WhiteBtnBackground: Color
    get() = themeColor(Color(0xFFF5F5F5), Color(0xFF2D2D2D))    // 动作按钮：深主题白底 / 浅主题黑灰底 [输入框]
val RemoveButtonBackground: Color
    get() = themeColor(Color(0xCC1E1E1E), SoftWhiteSurface.copy(alpha = 0.8f))    // 图片预览删除按钮（80% 卡片色）[输入框]

// ==================== 交互状态 ====================
val NewChatButton = Color(0xFFFF4500)          // New chat 主按钮橙红，两套主题一致 [抽屉]
val NewChatButtonPressed = Color(0xFFE03E00)   // 主按钮 hover / pressed [抽屉]
val SidebarItemActive: Color
    get() = themeColor(Color(0xFF2A2A2A), Color(0xFFDCDCDC))    // 历史项 hover / active 背景 [抽屉]
val IconButtonHover: Color
    get() = themeColor(Color(0xFF2A2A2A), Color(0xFFD6D6D6))    // 图标按钮 hover [抽屉]
val SettingItemPressed: Color
    get() = themeColor(Color(0x0AFFFFFF), Color(0x0F000000))    // 设置条目按下：深色底叠白 4% / 浅色底叠黑 6% [设置]
val MenuButtonBackground = Color.Transparent   // 移动端菜单按钮底 [抽屉]

// ==================== 强调色 ====================
val AccentOrange = Color(0xFFFF5722)           // 主强调橙 --accent：光标条 / 设置图标 / 退出登录，两套主题一致
// 思考卡片左侧竖条：强调橙透明度降低 30%（70% 不透明度），视觉更柔和 [message]
val ReasoningBarColor = Color(0xB3FF5722)
// 文本选区高亮：强调橙提高透明度（25% 不透明度），不盖住正文 [message]
val TextSelectionBackground = Color(0x40FF5722)
// 文本选区拖拽手柄：强调橙轻度半透明（80% 不透明度）[message]
val TextSelectionHandle = Color(0xCCFF5722)
// 「回到底部」按钮非输出态图标：白 70% 不透明度；浅色主题下同档黑，避免白底看不见 [message]
val ScrollButtonIdleIcon: Color
    get() = themeColor(OffWhiteText.copy(alpha = 0.7f), Color(0xB31A1A1A))    // 柔白 70% / 黑 70%

// ==================== 文本与图标 ====================
val TextWhite: Color
    get() = themeColor(OffWhiteText, Color(0xFF1A1A1A))         // 高亮文本 / 标题（浅色主题下为黑）[抽屉]
val TextGray300: Color
    get() = themeColor(Color(0xFFD1D5DB), Color(0xFF374151))    // 历史项默认文本 [抽屉]
val TextGray400: Color
    get() = themeColor(Color(0xFF9CA3AF), Color(0xFF6B7280))    // 图标 / 次要文本 [抽屉]
val TextGray500: Color
    get() = themeColor(Color(0xFF6B7280), Color(0xFF9CA3AF))    // 分组标题 / 占位提示 [抽屉]
val SettingValueText: Color
    get() = themeColor(Color(0xFF9E9E9E), Color(0xFF616161))    // 设置条目右侧数值 --sub [设置]
val SettingChevron: Color
    get() = themeColor(Color(0xB39E9E9E), Color(0xB3616161))    // 右向箭头：次要文本色叠加 70% 透明度 [设置]
val InputTextColor: Color
    get() = themeColor(Color(0xFFE0E0E0), Color(0xFF1A1A1A))    // 输入文字 [输入框]
val UserMessageText: Color
    get() = themeColor(Color(0xFFE0E0E0), Color(0xFF1A1A1A))    // 用户消息文字（与输入文字同值）
val InputPlaceholderColor: Color
    get() = themeColor(Color(0xFF888888), Color(0xFF9E9E9E))    // 占位文字 [输入框]
val ModeTextColor: Color
    get() = themeColor(Color(0xFFBBBBBB), Color(0xFF555555))    // 模式选择文字 / 下三角 [输入框]
val AssistantTextColor: Color
    get() = themeColor(OffWhiteText, Color(0xFF1A1A1A))         // AI 回答正文 [message]
val ReasoningTextColor: Color
    get() = themeColor(Color(0xFF9E9E9E), Color(0xFF616161))    // AI 思考内容灰色（与设置数值同值）[message]
val BtnAddIcon: Color
    get() = themeColor(Color(0xFFCCCCCC), Color(0xFF444444))    // “+”按钮图标 [输入框]
val WhiteBtnIcon: Color
    get() = themeColor(Color(0xFF1A1A1A), Color(0xFFF5F5F5))    // 动作按钮图标：与 WhiteBtnBackground 反转配对 [输入框]

// ==================== 分隔线与边框 ====================
val SidebarDivider: Color
    get() = themeColor(Color(0xFF252525), Color(0xFFD9D9D9))    // 侧边栏底部分隔线 [抽屉]
val SearchModalBorder: Color
    get() = themeColor(Color(0xFF333333), Color(0xFFC7C7C7))    // 搜索弹窗边框 [抽屉]
val BtnAddBorder: Color
    get() = themeColor(Color(0xFF555555), Color(0xFFA3A3A3))    // “+”按钮边框 [输入框]

// ==================== 小程序（景区助手）====================
// 呼应 UI设计/小程序选项UI参考.html：面板行分隔线 .panel-row border-bottom #2e2e2e，
// 浅色主题按“深底变浅底”规则取反为中性浅灰。
val MiniPanelDivider: Color
    get() = themeColor(Color(0xFF2E2E2E), Color(0xFFDDDDE0))    // 面板网格行之间的分隔线 [小程序]

// ==================== 路线规划小程序 ====================
// 地图卡片相关中性色；强调一律用 AccentOrange（线条 / 站点序号 / 选中胶囊），不另引入新色相。
val MapPlaceholderBackground: Color
    get() = themeColor(Color(0xFF232327), Color(0xFFEDEEF1))    // 地图加载 / 不可用时的占位底 [路线规划]
val RouteChipSelectedBackground: Color
    get() = themeColor(Color(0x2E5722), Color(0x14FF5722))      // 出行方式选中胶囊底：强调橙 18% / 12% [路线规划]
val RouteStopSelectedBackground: Color
    get() = themeColor(Color(0x14FFFFFF), Color(0x0FFF5722))    // 时间线站点选中底：深叠白 8% / 浅叠橙 6% [路线规划]
val RouteTimelineConnector: Color
    get() = themeColor(Color(0xFF3A3A3A), Color(0xFFD5D5D9))    // 时间线竖向连线 [路线规划]

// ==================== 附件动作面板（“+”展开：拍照 / 相册 / 本地文件）====================
// 呼应 UI设计/输入框文件参考UI初稿.html 的 action-item：黑白为主， tiles 比卡片略作明暗对比，
// 图标与文字统一走黑 / 柔白，按压态轻微加深，不使用彩色。
val AttachmentTileBackground: Color
    get() = themeColor(Color(0xFF3A3A3A), Color(0xFFF1F1F3))    // 动作瓷砖底：深主题比卡片略亮 / 浅主题柔白偏灰 [输入框]
val AttachmentTilePressed: Color
    get() = themeColor(Color(0xFF474747), Color(0xFFE4E4E7))    // 动作瓷砖按压 / hover [输入框]
val AttachmentTileText: Color
    get() = themeColor(OffWhiteText, Color(0xFF333333))         // 动作瓷砖文字：深柔白 / 浅近黑 [输入框]
val AttachmentTileIcon: Color
    get() = themeColor(OffWhiteText, Color(0xFF3A3A3A))         // 动作瓷砖图标：深柔白 / 浅深灰 [输入框]
val FileChipBackground: Color
    get() = themeColor(Color(0xFF3A3A3A), Color(0xFFF1F1F3))    // 已选文件条幅底（与动作瓷砖同档）[输入框]
val FileChipText: Color
    get() = themeColor(OffWhiteText, Color(0xFF333333))         // 已选文件名文字 [输入框]
val AttachmentHintText: Color
    get() = themeColor(Color(0xFFFF8A65), Color(0xFFD93025))    // 附件不支持格式等提示：深柔橙 / 浅标准红 [输入框]
val SettingDivider: Color
    get() = themeColor(Color(0x0DFFFFFF), Color(0x14000000))    // 卡片内分隔线：深叠白 5% / 浅叠黑 8% [设置]

// ==================== 消息动作按钮 / 提示 / 反馈面板 ====================
val ActionIconColor: Color
    get() = themeColor(OffWhiteText, Color(0xFF1A1A1A))         // 正文下方动作图标：深色柔白 / 浅色黑 [message]
val FeedbackAccent: Color = Color(0xFF2F6BFF)                   // 反馈面板选中态蓝 [反馈]
val ToastBackground: Color
    get() = themeColor(Color(0xE62A2B32), Color(0xE6333333))    // 顶部提示胶囊底 [反馈]
val ToastText: Color = OffWhiteText                             // 顶部提示文字，两套主题都是柔白 [反馈]
val SheetBackground: Color
    get() = themeColor(Color(0xFF141418), SoftWhiteSurface)     // 底部动作面板底 [反馈]
val SheetHandle: Color
    get() = themeColor(Color(0xFF3A3A42), Color(0xFFC7C7C7))    // 面板顶部拖拽条 [反馈]
val SheetDivider: Color
    get() = themeColor(Color(0xFF202025), Color(0xFFE6E6E6))    // 面板标题栏分隔线 [反馈]
val ChipBorder: Color
    get() = themeColor(Color(0xFF2C2D34), Color(0xFFD5D5D5))    // 反馈标签默认边框 [反馈]
val ChipSelectedBackground: Color
    get() = themeColor(Color(0x1F2F6BFF), Color(0x142F6BFF))    // 反馈标签选中底：蓝色 12% / 8% [反馈]
val ChipSelectedText: Color
    get() = themeColor(Color(0xFFC9DBFF), Color(0xFF2F6BFF))    // 反馈标签选中文字 [反馈]
val SubmitDisabledBackground: Color
    get() = themeColor(Color(0xFF25262C), Color(0xFFE0E0E0))    // 提交按钮不可用底 [反馈]
val SubmitDisabledText: Color
    get() = themeColor(Color(0xFF9A9AA0), Color(0xFF8A8A90))    // 提交按钮不可用文字 [反馈]
val SubmitReadyBackground: Color
    get() = themeColor(Color(0xFFECECF0), Color(0xFF1A1A1A))    // 提交按钮可用底：与主题反转 [反馈]
val SubmitReadyText: Color
    get() = themeColor(Color(0xFF141418), Color(0xFFF5F5F5))    // 提交按钮可用文字 [反馈]

// ==================== 登录 / 注册表单 ====================
val FormErrorText: Color
    get() = themeColor(Color(0xFFFF6B6B), Color(0xFFD93025))    // 字段校验错误红字（深主题浅红 / 浅主题标准红）[登录]

// ==================== Markdown 渲染 ====================
val CodeBlockBackground: Color
    get() = themeColor(Color(0xFF232327), Color(0xFFEDEDED))    // 代码块容器底 [markdown]
val CodeBlockText: Color
    get() = themeColor(Color(0xFFD4D4D8), Color(0xFF27272A))    // 代码块文字 [markdown]
val InlineCodeBackground: Color
    get() = themeColor(Color(0xFF2A2A2E), Color(0xFFE4E4E4))    // 行内代码底 [markdown]
val MarkdownLinkColor: Color
    get() = themeColor(Color(0xFF7BA4FF), Color(0xFF2F6BFF))    // 链接文字 [markdown]
val QuoteBarColor: Color
    get() = themeColor(Color(0xFF3A3B43), Color(0xFFC9C9CF))    // 引用左侧竖条 [markdown]

// ==================== 工具调用卡片 ====================
// 工具调用从思考文本中拆出，用与强调橙区分的蓝色系做成独立卡片行。
val ToolCallAccent: Color = Color(0xFF3B82F6)                  // 工具图标 / 强调蓝（呼应反馈蓝系）
val ToolCallChipBackground: Color
    get() = themeColor(Color(0x1F3B82F6), Color(0x143B82F6))    // 工具卡片底：蓝色 12% / 8% [message]
val ToolCallTextColor: Color
    get() = themeColor(Color(0xFF9FC2FF), Color(0xFF2F6BFF))    // 工具卡片文字：深浅蓝 / 浅标准蓝 [message]

// ==================== 阴影与遮罩 ====================
val InputCardShadow: Color
    get() = themeColor(Color(0x4D000000), Color(0x26000000))    // 卡片阴影（浅色主题下减淡）[输入框]
val SearchScrim: Color
    get() = themeColor(Color(0x99000000), Color(0x66000000))    // 弹窗遮罩（浅色主题下减淡）[抽屉]

// ==================== 渐变 ====================
/** 聊天顶栏横向两端淡出衬底，跟随页面背景色 [抽屉] */
val TopBarEdgeFadeBrush: Brush
    get() {
        val base = ChatBackground
        return Brush.horizontalGradient(
            colorStops = arrayOf(
                0.0f  to base.copy(alpha = 0.65f),
                0.25f to base.copy(alpha = 0.6f),
                0.35f to base.copy(alpha = 0.2f),
                0.5f  to Color.Transparent,
                0.65f to base.copy(alpha = 0.2f),
                0.75f to base.copy(alpha = 0.6f),
                1.0f  to base.copy(alpha = 0.65f),
            )
        )
    }
